Cybershop.grid.Complects = function(config) {
    config = config || {};
    Ext.applyIf(config,{
        url: Cybershop.config.connectorUrl
        ,baseParams: { action: 'mgr/catalog/catalogcomplecttable/getList'}
        ,save_action: 'mgr/catalog/catalogcomplecttable/updateFromGrid' 
        ,fields: ['id','name','catalog'
                  ,'description','introtext'
                  ,'fulltext','image'
                  ,'url','ceo_data'
                  ,'ceo_data','ceo_description'
                  ,'amount']
        ,paging: true
        ,pageSize: 5
        ,autosave: true
        ,remoteSort: true
        ,anchor: '99%'
        ,autoExpandColumn: 'name'
        ,columns: [{
            header: _('cs_id')
            ,dataIndex: 'id'
            ,sortable: true
            ,width: 60
        },{
            header: _('cs_image')
            ,dataIndex: 'image'
            ,sortable: true
            ,renderer: this.renderItemImage
            ,width: 100
        },{
            header: _('cs_name')
            ,dataIndex: 'name'
            ,sortable: true
            ,width: 100
        },{
            header: _('cs_description')
            ,dataIndex: 'description'
            ,sortable: false
            ,width: 350
        },{
            header: _('cs_amount')
            ,dataIndex: 'amount'
            ,sortable: false
            ,width: 350
        }]

	,tbar: 
            [{
                text: _('cs_element_create')
                ,handler: this.createNewElement
            }]

       
     });
    Cybershop.grid.Complects.superclass.constructor.call(this,config);

};

Ext.extend(Cybershop.grid.Complects,MODx.grid.Grid,{
        setFilter: function() {
            this.getStore().baseParams.catalog = this.config.filterId;
            this.getBottomToolbar().changePage(1);
            this.refresh();
            return true;
        }
        ,getMenu: function() {
            return [{
                 text: _('cs_element_create')
                 ,handler: this.createNewElement
            },{
                 text: _('cs_element_update')
                 ,handler: this.updateElement
            },{
                 text: _('cs_element_remove')
                 ,handler: this.removeElement
            }];
        }
        ,removeElement: function() {
            MODx.msg.confirm({
            title: _('cs_element_remove')
            ,text: _('cs_element_remove_confirm')
            ,url: this.config.url
            ,params: {
                action: 'mgr/catalog/catalogcomplecttable/remove'
                ,id: this.menu.record.id
            }
            ,listeners: {
                'success': {fn:this.refresh,scope:this}
            }
            });
        }
        ,createNewElement: function() {
            parentCmp = Ext.getCmp(this.config.winid);

            if (parentCmp.blankValues){

                Ext.Msg.confirm(_('cs_element_save'),_('cs_element_save_confirm'),function(e) {
                    if (e == 'yes') {
//                        this.addListener('success',function(response){
//                            alert(response.a);
//                        },this);
                        parentCmp.savenew();
//                        this.createNewElementWindow();
                        return;
                        }
                    else {
                        return;
                    }
                },this);
            }
            else{
                this.createNewElementWindow();
                return;
            }
        }
        ,createNewElementWindow: function() {
            if (!this.createElementWindow) {
                this.createElementWindow = new MODx.load({
                        xtype: 'cybershop-window-complects'
                        ,title: _('cs_element_create')
                        ,baseParams: {action: 'mgr/catalog/catalogcomplecttable/create'}
                        ,listeners: {
                            'success': {fn:this.refresh,scope:this}
                            }
                    });
            };
            this.createElementWindow.config.blankValues = true;
            this.createElementWindow.config.winid = this.config.id;
            this.createElementWindow.show(); 
            this.createElementWindow.fp.getForm().items.itemAt(1).setValue(this.config.filterId);
                  
        }
        ,updateElement: function(n,e) {
            if (!this.updateWindow) {
                this.updateWindow = MODx.load({
                    xtype: 'cybershop-window-complects'
                    ,record: this.menu.record
                    ,listeners: {
                        'success': {fn:this.refresh,scope:this}
                    }
                });
            }
            this.updateWindow.setValues(this.menu.record);
            this.updateWindow.show(e.target);
        }
        ,renderItemImage: function(v,md,rec) {
            var image_path = v!='' ? MODx.config.base_url+'connectors/system/phpthumb.php?w=40&h=40&src='+MODx.config.base_url+v : '';
            var out = image_path!='' ? '<img src="'+image_path+'" width="40" height="40" alt="'+v+'" title="'+v+'" />' : '';
            return out;
        }
});
Ext.reg('cybershop-grid-complects',Cybershop.grid.Complects);

Cybershop.window.Complects = function(config) {
    config = config || {};
    config.id = Ext.id();
    Ext.applyIf(config,{
        title: _('cs_element_update')
        ,id: config.id
        ,url: Cybershop.config.connectorUrl
        ,baseParams: {
            action: 'mgr/catalog/catalogcomplecttable/update'
        }
        ,width: 700  
        ,minWidth:700 
        ,fields:
            [{
                xtype: 'hidden'
                ,name: 'id'
            },{
                xtype: 'hidden'
                ,name: 'catalog'
            },{
                xtype: 'panel'
                ,border: false
                ,cls:'main-wrapper'
                ,layout: 'form'
                ,labelAlign: 'top'
                ,labelSeparator: ''
                ,items: [{
                    xtype: 'modx-tabs'
                    ,defaults: {
                                    autoHeight: true
                                    ,border: true
                                    ,bodyCssClass: 'tab-panel-wrapper'
                    }
                    ,forceLayout: true
                    ,deferredRender: false
                    ,items: 
                        [{
                            title: _('cs_tabs_main')
                            ,layout: 'form'
                            ,items: 
                                [{
                                    xtype: 'textfield'
                                    ,fieldLabel: _('cs_name')
                                    ,name: 'name'
                                    ,anchor: '99%'
                                },{
                                    xtype: 'textfield'
                                    ,fieldLabel: _('cs_description')
                                    ,name: 'description'
                                    ,anchor: '99%'
                                },{
                                    xtype: 'textarea'
                                    ,fieldLabel: _('cs_introtext')
                                    ,name: 'introtext'
                                    ,anchor: '99%'
                                },{
                                     xtype: 'htmleditor'
                                    ,hideLabel: true
                                    ,fieldLabel: _('cs_fulltext')
                                    ,name: 'fulltext'
                                    ,anchor: '99%'
                                    ,minWidth: 700
                                    ,handler: function(){
                                        Ext.get('styleswitcher').on('click', function(e){
                                            Ext.getCmp('form-widgets').getForm().reset();
                                        });
                                    }

                                }]
                        },{
                            title: _('cs_tabs_add')
                            ,layout: 'form'
                            ,items: 
                                [{
                                    xtype: 'numberfield'
                                    ,fieldLabel: _('cs_amount')
                                    ,name: 'amount'
                                    ,anchor: '99%'
                                 },{
                                    xtype: 'textfield'
                                    ,fieldLabel: _('cs_url')
                                    ,name: 'url'
                                    ,anchor: '99%'
                                 },{
                                    xtype: 'modx-combo-browser'
                                    ,fieldLabel: _('cs_image')
                                    ,name: 'image'
                                    ,anchor: '99%'
                                    ,source: '2'
                                 }]

                         },{
                            title: _('cs_tabs_ceo')
                            ,layout: 'form'
                            ,items:  
                                [{
                                    xtype: 'textfield'
                                    ,fieldLabel: _('cs_ceo_data')
                                    ,name: 'ceo_data'
                                    ,anchor: '99%'
                                },{
                                    xtype: 'textfield'
                                    ,fieldLabel: _('cs_ceo_key')
                                    ,name: 'ceo_key'
                                    ,anchor: '99%'
                                },{
                                    xtype: 'textarea'
                                    ,fieldLabel: _('cs_ceo_description')
                                    ,name: 'ceo_description'
                                    ,anchor: '99%'                                
                                }]
                         }]
                }]
            }]
    });
    Cybershop.window.Complects.superclass.constructor.call(this,config);
};

Ext.extend(Cybershop.window.Complects,MODx.Window);
Ext.reg('cybershop-window-complects',Cybershop.window.Complects);



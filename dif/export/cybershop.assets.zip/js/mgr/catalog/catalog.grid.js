
Cybershop.grid.Catalog = function(config) {
    config = config || {};
    config.id = Ext.id();
    Ext.applyIf(config,{
        id: config.id
        ,url: Cybershop.config.connectorUrl
        ,baseParams: { action: 'mgr/catalog/getList' }
        ,save_action: 'mgr/catalog/updateFromGrid'
        ,fields: ['id','name','description','article'
                 ,'image','brand','brand_name','category'
                 ,'category_name','made_in','media'
                 ,'price1','price2','price3','weight'
                 ,'active','deleted','new'
                 ,'sellout','discount','onhomepage'
                 ,'url','ceo_data','ceo_key','ceo_description']
        ,paging: true
        ,autosave: true
        ,remoteSort: true
        ,anchor: '99%'
        ,autoExpandColumn: 'name'
        ,columns: [{
            header: _('cs_id')
            ,dataIndex: 'id'
            ,sortable: true
            ,width: 60
        },{
            header: _('cs_active')
            ,dataIndex: 'active'
            ,sortable: true
            ,width: 30
            ,renderer: this.renderBoolean
        },{
            header: _('cs_deleted')
            ,dataIndex: 'deleted'
            ,sortable: true
            ,width: 30
            ,renderer: this.renderBoolean
        },{
            header: _('cs_image')
            ,dataIndex: 'image'
            ,sortable: false
            ,renderer: this.renderImg
            ,width: 100
        },{
            header: _('cs_name')
            ,dataIndex: 'name'
            ,sortable: true
            ,width: 100
        },{
            header: _('cs_description')
            ,dataIndex: 'description'
            ,sortable: false
            ,width: 350
        },{
            header: _('cs_article')
            ,dataIndex: 'article'
            ,sortable: true
            ,width: 100
        },{
	     header: _('cs_brand')
            ,dataIndex: 'brand_name'
            ,sortable: true
            ,width: 100
        },{
	     header: _('cs_category')
            ,dataIndex: 'category_name'
            ,sortable: true
            ,width: 100
        },{	
	     header: _('cs_price1')
            ,dataIndex: 'price1'
            ,sortable: true
            ,width: 100
        }]
       ,tbar: [{
            text: _('cs_element_create')
            ,handler: { 
                xtype: 'cybershop-window-catalog' 
                ,blankValues: true 
                ,title: _('cs_element_create')
                ,baseParams: {
                    action: 'mgr/catalog/create'
                }
            }
        },'->',{
            xtype: 'modx-combo'
            ,id: config.id+'-combo-brands'
            ,name: 'brands'
            ,itemId: 'brands'
            ,emptyText: _('cs_selectElement')+'...'
            ,url: Cybershop.config.connectorUrl
            ,baseParams: {
                action: 'mgr/brands/getList'
                ,combo: true
                ,addall: true
            }
   //         ,value: MODx.request['usergroup'] ? MODx.request['usergroup'] : ''
            ,width: 200
            ,listeners: {
                'select': {fn:this.filterBrands,scope:this}
            }
        },'-',{
            xtype: 'modx-combo'
            ,id: config.id+'-combo-categorys'
            ,name: 'categorys'
            ,itemId: 'categorys'
            ,emptyText: _('cs_selectElement')+'...'
            ,url: Cybershop.config.connectorUrl
            ,baseParams: {
                action: 'mgr/categorys/getList'
                ,combo: true
                ,addall: true
            }
  //          ,value: MODx.request['usergroup'] ? MODx.request['usergroup'] : ''
            ,width: 200
            ,listeners: {
                'select': {fn:this.filterCategorys,scope:this}
            }
        },'-',{
            xtype: 'textfield'
            ,id: config.id+'-search-filter'
            ,emptyText: _('cs_search...')
            ,listeners: {
                'change': {fn:this.search,scope:this}
                ,'render': {fn: function(cmp) {
                    new Ext.KeyMap(cmp.getEl(), {
                        key: Ext.EventObject.ENTER
                        ,fn: function() {
                            this.fireEvent('change',this);
                            this.blur();
                            return true;
                        }
                        ,scope: cmp
                    });
                },scope:this}
            }
         },{
            xtype: 'button'
            ,id: config.id+'-filter-clear'
            ,text: _('filter_clear')
            ,listeners: {
                'click': {fn: this.clearFilter, scope: this}
            }
        }]
    });
    Cybershop.grid.Catalog.superclass.constructor.call(this,config)
};
Ext.extend(Cybershop.grid.Catalog,MODx.grid.Grid,{
    search: function(tf,nv,ov) {
        var s = this.getStore();
        s.baseParams.query = tf.getValue();
        this.getBottomToolbar().changePage(1);
        this.refresh();
    }
    ,filterBrands: function(cb,nv,ov) {
        this.getStore().baseParams.brand = Ext.isEmpty(nv) || Ext.isObject(nv) ? cb.getValue() : nv;
        this.getBottomToolbar().changePage(1);
        this.refresh();
        return true;
    }
    ,filterCategorys: function(cb,nv,ov) {
        this.getStore().baseParams.category = Ext.isEmpty(nv) || Ext.isObject(nv) ? cb.getValue() : nv;
        this.getBottomToolbar().changePage(1);
        this.refresh();
        return true;
    }
    ,clearFilter: function() {
    	this.getStore().baseParams = {
            action: 'mgr/catalog/getList'
    	};
        Ext.getCmp(this.config.id+'-search-filter').reset();
        Ext.getCmp(this.config.id+'-combo-categorys').reset();
        Ext.getCmp(this.config.id+'-combo-brands').reset();
    	this.getBottomToolbar().changePage(1);
        this.refresh();
    }
    ,getMenu: function() {
        return [{
             text: _('cs_element_create')
            ,handler: { 
                xtype: 'cybershop-window-catalog' 
                ,blankValues: true 
                ,title: _('cs_element_create')
                ,baseParams: {
                    action: 'mgr/catalog/create'
                }
            }
        },{
            text: _('cs_element_update')
            ,handler: this.updateElement
        },{
            text: _('cs_element_remove')
            ,handler: this.removeElement
        }];
    }
    ,updateElement: function(btn,e,row) {
        if (typeof(row) != 'undefined') {this.menu.record = row.data;}
        var id = this.menu.record.id;

        MODx.Ajax.request({
                url: Cybershop.config.connectorUrl
                ,params: {
                        action: 'mgr/catalog/get'
                        ,id: id
                }
                ,listeners: {
                        'success': {fn:function(r) {
                                if (!this.updateCatalogWindow) {
                                    this.updateCatalogWindow = MODx.load({
                                        xtype: 'cybershop-window-catalog'
                                        ,title: _('cs_element_update')
                                        ,record: this.menu.record
                                        ,listeners: {
                                            'success': {fn:this.refresh,scope:this}
                                        }
                                    });
                                }
                                this.updateCatalogWindow.setValues(this.menu.record);
                                this.updateCatalogWindow.show(e.target);
                        },scope:this}
                }
        });
    }
    ,removeElement: function() {
        MODx.msg.confirm({
            title: _('cs_element_remove')
            ,text: _('cs_element_remove_confirm')
            ,url: this.config.url
            ,params: {
                action: 'mgr/catalog/remove'
                ,id: this.menu.record.id
            }
            ,listeners: {
                'success': {fn:this.refresh,scope:this}
            }
        });
    }
    ,renderImg: function(v,md,rec) {
        var image_path = v!='' ? MODx.config.base_url+'connectors/system/phpthumb.php?w=80&h=80&src='+MODx.config.base_url+v : '';
        var out = image_path!='' ? '<img src="'+image_path+'" width="80" height="80" alt="'+v+'" title="'+v+'" />' : '';
        return out;
/*	img_lwc = img.toLowerCase();
	if (img.length > 0) {
		if (!/(jpg|jpeg|png|gif|bmp)$/.test(img_lwc)) {return img;}
		else if (/^(http|https|\/)/.test(img_lwc)) {return '<img src="'+img+'" alt="" style="display:block;margin:auto;height:30px;" />'}
		else {return '<img src="/'+img+'" alt="" style="display:block;margin:auto;height:30px;" />'}
	}
	else {return '';}
*/    }
    ,renderBoolean: function(value) {
            if (value == 1) {return _('yes');}
            else {return _('no');}
    }
});
Ext.reg('cybershop-grid-catalog',Cybershop.grid.Catalog);


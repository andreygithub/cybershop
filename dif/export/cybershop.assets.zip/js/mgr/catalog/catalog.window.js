
Cybershop.window.Catalog = function(config) {
    config = config || {};
    config.id = Ext.id();
    Ext.applyIf(config,{
        id: config.id
        ,url: Cybershop.config.connectorUrl
        ,baseParams: {
            action: 'mgr/catalog/update'
        }
        ,width: 1000  //maximized: true 
        ,minWidth:700
        ,fields: 
        [{
            xtype: 'hidden'
            ,name: 'id'
        },{
                xtype: 'panel'
                ,border: false
                ,cls:'main-wrapper'
                ,layout: 'form'
                ,labelAlign: 'top'
                ,labelSeparator: ''
                ,items: 
                [{
                    xtype: 'modx-tabs'
                    ,defaults: {
                                autoHeight: true
                                ,border: true
                                ,bodyCssClass: 'tab-panel-wrapper'
                                }
                    ,forceLayout: true
                    ,deferredRender: false
                    ,items: 
                    [{                   
                        title: _('cs_tabs_main')
                        ,layout: 'form'
                        ,items: 
                        [{
                            xtype: 'textfield'
                            ,fieldLabel: _('cs_name')
                            ,name: 'name'
                            ,anchor: '99%'      
                        },{
                            xtype: 'textfield'
                            ,fieldLabel: _('cs_description')
                            ,name: 'description'
                            ,anchor: '99%'
                        },{
                            xtype: 'textfield'
                            ,fieldLabel: _('cs_article')
                            ,name: 'article'
                            ,anchor: '99%'
                        },{
                            xtype: 'textarea'
                            ,fieldLabel: _('cs_introtext')
                            ,name: 'introtext'
                            ,anchor: '99%'
                        },{
                             xtype: 'htmleditor'
                            ,hideLabel: true
                            ,fieldLabel: _('cs_fulltext')
                            ,name: 'fulltext'
                            ,anchor: '99%'
                            ,minWidth: 700
                            ,handler: function(){
                                Ext.get('styleswitcher').on('click', function(e){
                                    Ext.getCmp('form-widgets').getForm().reset();
                                });
                            }

                        }]
                    },{
                        title: _('cs_tabs_filters')
                        ,layout: 'form'
                        ,items: 
                        [{
                            xtype: 'modx-combo'
                            ,fieldLabel: _('cs_brand')
                            ,name: 'brand'
                            ,hiddenName: 'brand'
                            ,emptyText: _('cs_selectElement')+'...'
                            ,url: Cybershop.config.connectorUrl
                            ,baseParams: {
                                action: 'mgr/brands/getList'
                                ,addAll: false
                            }
                            ,pageSize: 20
                            ,anchor: '99%'
                        },{
                            xtype: 'modx-combo'
                            ,fieldLabel: _('cs_category')
                            ,name: 'category'
                            ,hiddenName: 'category'
                            ,emptyText: _('cs_selectElement')+'...'
                            ,url: Cybershop.config.connectorUrl
                            ,baseParams: {
                                action: 'mgr/categorys/getList'
                                ,combo: true
                                ,addAll: false
                            }
                            ,pageSize: 20
                            ,anchor: '99%'
                        },{
                            xtype: 'cybershop-grid-filtertable'
                            ,id: config.id+'-grid-filtertable'
                            ,winid: config.id
                            ,fieldLabel: _('cs_filters')
                            ,name: 'id'
                            ,anchor: '99%' 
                        }]
                    },{
                        title: _('cs_tabs_complects')
                        ,layout: 'form'
                        ,items: 
                        [{
                            xtype: 'cybershop-grid-complects'
                            ,id: config.id+'-grid-complects'
                            ,winid: config.id
                            ,fieldLabel: _('cs_grid_complects')
                            ,name: 'id'
                            ,anchor: '99%'        
                        }]
                    },{
                        title: _('cs_tabs_price')
                        ,layout: 'form'
                        ,items: 
                        [{
                            xtype: 'numberfield'
                            ,fieldLabel: _('cs_price1')
                            ,name: 'price1'
                            ,decimalPrecision: 2
                            ,anchor: '99%'      
                        },{
                            xtype: 'numberfield'
                            ,fieldLabel: _('cs_price2')
                            ,name: 'price2'
                            ,decimalPrecision: 2
                            ,anchor: '99%'      
                        },{
                            xtype: 'numberfield'
                            ,fieldLabel: _('cs_price3')
                            ,name: 'price3'
                            ,decimalPrecision: 2
                            ,anchor: '99%'  
                        },{
                            xtype: 'numberfield'
                            ,fieldLabel: _('cs_weight')
                            ,name: 'weight'
                            ,decimalPrecision: 3
                            ,anchor: '99%' 
                        }]
                    },{
                        title: _('cs_tabs_images')
                        ,layout: 'form'
                        ,items: 
                        [{
                            xtype: 'cybershop-grid-images'
                            ,id: config.id+'-grid-images'
                            ,winid: config.id
                            ,fieldLabel: _('cs_grid_images')
                            ,name: 'id'
                            ,anchor: '99%'        
                        }]
                    },{
                        title: _('cs_tabs_similars')
                        ,layout: 'form'
                        ,items: 
                        [{
                            xtype: 'cybershop-grid-similars'
                            ,id: config.id+'-grid-similars'
                            ,winid: config.id
                            ,fieldLabel: _('cs_grid_similars')
                            ,name: 'id'
                            ,anchor: '99%'        
                        }]
                    },{
                        
                        title: _('cs_tabs_status')
                        ,layout: 'form'
                        ,items: 
                        [{
                            xtype: 'checkboxgroup'
                            ,fieldLabel: _('cs_options')
                            ,columns: 1
                            ,items: 
                            [{
                                xtype: 'xcheckbox'
                                ,boxLabel: _('cs_active')
                                ,name: 'active'
                                 ,anchor: '99%' 
                            },{
                                xtype: 'xcheckbox'
                                ,boxLabel: _('cs_deleted')
                                ,name: 'deleted'
                                ,anchor: '99%' 
                            },{
                                xtype: 'xcheckbox'
                                ,boxLabel: _('cs_new')
                                ,name: 'new'
                                ,anchor: '99%'   
                            },{
                                xtype: 'xcheckbox'
                                ,boxLabel: _('cs_sellout')
                                ,name: 'sellout'
                                ,anchor: '99%' 
                            },{
                                xtype: 'xcheckbox'
                                ,boxLabel: _('cs_discount')
                                  ,name: 'discount'
                                ,anchor: '99%'   
                            },{
                                xtype: 'xcheckbox'
                                ,boxLabel: _('cs_onhomepage')
                                ,name: 'onhomepage'
                                ,anchor: '99%'  
                            }]
                        }]
                    },{
                        
                        title: _('cs_tabs_add')
                        ,layout: 'form'
                        ,items: 
                        [{
                            xtype: 'textfield'
                            ,fieldLabel: _('cs_made_in')
                            ,name: 'made_in'
                            ,anchor: '99%' 
                        },{
                            xtype: 'textfield'
                            ,fieldLabel: _('cs_url')
                            ,name: 'url'
                            ,anchor: '99%'      
                        },{
                            xtype: 'modx-combo-browser'
                            ,fieldLabel: _('cs_main_image')
                            ,name: 'image'
                            ,anchor: '99%'
                            ,source: '2' 
                       },{
                            xtype: 'modx-combo-browser'
                            ,fieldLabel: _('cs_media')
                            ,name: 'media'
                            ,anchor: '99%'
                            ,source: '2'
                        }]
                    },{
                        title: _('cs_tabs_ceo')
                        ,layout: 'form'
                        ,items:  
                        [{
                            xtype: 'textfield'
                            ,fieldLabel: _('cs_ceo_data')
                            ,name: 'ceo_data'
                            ,anchor: '99%'
                        },{
                            xtype: 'textfield'
                            ,fieldLabel: _('cs_ceo_key')
                            ,name: 'ceo_key'
                            ,anchor: '99%'
                        },{
                            xtype: 'textarea'
                            ,fieldLabel: _('cs_ceo_description')
                            ,name: 'ceo_description'
                            ,anchor: '99%'                                
                        }]
                    }]
                }]
        }]
   
    });
    Cybershop.window.Catalog.superclass.constructor.call(this,config);
    this.on('show',function() {
        if (this.config.blankValues) { 
            this.blankValues = true;
            this.fp.getForm().reset();
            this.fp.getForm().baseParams = this.config.baseParams;
            this.config.filterCatalog = -1;
            this.config.filterBrand = -1;
            this.config.filterCategory = -1;
            this.setTableFilterCatalog(this.config.filterCatalog);
            this.setTableFilterBrand(this.config.filterBrand);
            this.setTableFilterCategory(this.config.filterCategory);
            this.setTableFilter();
        }
        else {
            this.setTableFilterCatalog(this.fp.getForm().items.itemAt(0).getValue());
            this.setTableFilterBrand(this.fp.getForm().items.itemAt(6).getValue());
            this.setTableFilterCategory(this.fp.getForm().items.itemAt(7).getValue());
            this.setTableFilter();
        }
        if (this.config.allowDrop) { this.loadDropZones(); }
        this.syncSize();
        this.focusFirstField();
    },this);
};
Ext.extend(Cybershop.window.Catalog,MODx.Window,{
        savenew: function() {
            var f = this.fp.getForm();

            f.submit({
                waitMsg: _('saving')
                ,scope: this
                ,failure: function(frm,a) {
                    if (this.fireEvent('failure',{f:frm,a:a})) {
                        MODx.form.Handler.errorExt(a.result,frm);
                    }
                }
                ,success: function(frm,a) {

                    if (this.config.success) {
                        Ext.callback(this.config.success,this.config.scope || this,[frm,a]);
                        
                    }
                    this.fireEvent('success',{f:frm,a:a});
                    var r = Ext.decode(a.response.responseText);
                    this.setValues(r.object);
                    this.fp.getForm().baseParams = {action: 'mgr/catalog/update'};
                    this.blankValues = false;
                    this.setTableFilterCatalog(this.fp.getForm().items.itemAt(0).getValue());
                    this.setTableFilterBrand(this.fp.getForm().items.itemAt(6).getValue());
                    this.setTableFilterCategory(this.fp.getForm().items.itemAt(7).getValue());
                    this.setTableFilter();
                 }
            });
    }
    ,setTableFilterCatalog: function(filtervalue) {
        Ext.getCmp(this.config.id+'-grid-filtertable').config.filterCatalog = filtervalue;
        Ext.getCmp(this.config.id+'-grid-complects').config.filterId = filtervalue;
        Ext.getCmp(this.config.id+'-grid-similars').config.filterId = filtervalue;
        Ext.getCmp(this.config.id+'-grid-images').config.filterId = filtervalue;
    }
    ,setTableFilterBrand: function(filtervalue) {
        Ext.getCmp(this.config.id+'-grid-filtertable').config.filterBrand = filtervalue;
    }
    ,setTableFilterCategory: function(filtervalue) {
        Ext.getCmp(this.config.id+'-grid-filtertable').config.filterCategory = filtervalue;
    }
    ,setTableFilter: function() {
        Ext.getCmp(this.config.id+'-grid-filtertable').setFilter();
        Ext.getCmp(this.config.id+'-grid-complects').setFilter();
        Ext.getCmp(this.config.id+'-grid-similars').setFilter();
        Ext.getCmp(this.config.id+'-grid-images').setFilter();
    }

});
Ext.reg('cybershop-window-catalog',Cybershop.window.Catalog);


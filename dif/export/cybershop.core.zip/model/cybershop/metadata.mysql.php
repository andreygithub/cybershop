<?php

$xpdo_meta_map = array (
  'xPDOSimpleObject' => 
  array (
    0 => 'csCatalog',
    1 => 'csCatalogFilterTable',
    2 => 'csCatalogImageTable',
    3 => 'csCatalogComplectTable',
    4 => 'csCatalogSimilarTable',
    5 => 'csBrand',
    6 => 'csBrandTable',
    7 => 'csCategory',
    8 => 'csCategoryTable',
    9 => 'csFilter',
    10 => 'csFilterItem',
    11 => 'csDelivery',
    12 => 'csPayment',
    13 => 'csOrder',
    14 => 'csOrderStatus',
    15 => 'csOrderLog',
    16 => 'csOrderAddress',
    17 => 'csOrderProduct',
  ),
);
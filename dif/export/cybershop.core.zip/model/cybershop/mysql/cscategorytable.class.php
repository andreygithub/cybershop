<?php
require_once (dirname(dirname(__FILE__)) . '/cscategorytable.class.php');
class csCategoryTable_mysql extends csCategoryTable {}
<?php
$xpdo_meta_map['csFilterItem']= array (
  'package' => 'cybershop',
  'version' => '1.1',
  'table' => 'cybershop_filteritem',
  'extends' => 'xPDOSimpleObject',
  'fields' => 
  array (
    'filter' => 0,
    'name' => '',
    'description' => NULL,
    'image' => NULL,
  ),
  'fieldMeta' => 
  array (
    'filter' => 
    array (
      'dbtype' => 'int',
      'precision' => '10',
      'phptype' => 'integer',
      'null' => false,
      'default' => 0,
      'index' => 'index',
    ),
    'name' => 
    array (
      'dbtype' => 'varchar',
      'precision' => '255',
      'phptype' => 'string',
      'null' => false,
      'default' => '',
      'index' => 'index',
    ),
    'description' => 
    array (
      'dbtype' => 'text',
      'phptype' => 'string',
      'null' => true,
    ),
    'image' => 
    array (
      'dbtype' => 'varchar',
      'precision' => '255',
      'phptype' => 'string',
      'null' => true,
    ),
  ),
  'indexes' => 
  array (
    'filter' => 
    array (
      'alias' => 'filter',
      'primary' => false,
      'unique' => false,
      'type' => 'BTREE',
      'columns' => 
      array (
        'filter' => 
        array (
          'length' => '',
          'collation' => 'A',
          'null' => false,
        ),
      ),
    ),
    'name' => 
    array (
      'alias' => 'name',
      'primary' => false,
      'unique' => false,
      'type' => 'BTREE',
      'columns' => 
      array (
        'name' => 
        array (
          'length' => '',
          'collation' => 'A',
          'null' => false,
        ),
      ),
    ),
  ),
  'aggregates' => 
  array (
    'Filter' => 
    array (
      'class' => 'csFilter',
      'local' => 'filter',
      'foreign' => 'id',
      'cardinality' => 'many',
      'owner' => 'foreign',
    ),
    'CatalogFilterTable' => 
    array (
      'class' => 'csCatalogFilterTable',
      'local' => 'id',
      'foreign' => 'filteritem',
      'cardinality' => 'many',
      'owner' => 'foreign',
    ),
  ),
);

<?php


$dood = $modx->getService('doodles','Doodles',$modx->getOption('doodles.core_path',null,$modx->getOption('core_path').'components/doodles/').'model/doodles/',$scriptProperties);

$doodle = $modx->newObject('Doodle');
$doodle->fromArray(array(
    'name' => 'TestDoodle',
    'description' => 'A test doodle',
));
$doodle->save();

$doodle = $modx->newObject('Doodle');
$doodle->fromArray(array(
    'name' => 'Еще одна болванка',
    'description' => 'Я впервые появилась на свет!',
));
$doodle->save();
<?php
function findrow($arr,$find,$key){
        $row = 0;
        foreach ($arr as $r){
            if ($r[$key] == $find){
                return $row;
            }
            $row++;

        }
        return -1;
     }

$cs = $modx->getService('cybershop','Cybershop',$modx->getOption('cybershop.core_path',null,$modx->getOption('core_path').'components/cybershop/').'model/cybershop/',$scriptProperties);
        print 'start cybershop!!! <br>';
        $catalog = 2;
 
 //       $records = $this->modx->getCollection('csFilter');
        $q=$modx->newQuery('csFilter');
        $q->innerJoin('csBrandTable', 'BrandTable'); 
        $q->innerJoin('csCategoryTable', 'CategoryTable'); 


//        $q->leftJoin('csFilterItem', 'FilterItem','FilterItem.filter = csFilter.id'); 
//        $q->leftJoin('csCatalogFilterTable', 'CatalogFilterTable','CatalogFilterTable.filteritem = FilterItem.id'); 
//        $q->leftJoin('csFilterItem', 'FItem','FItem.id = CatalogFilterTable.filteritem'); 

        $q->where(array(
                        'BrandTable.brand' => 1,
                        'CategoryTable.category' => 4,
//                        '(CatalogFilterTable.catalog = '.$catalog.' OR CatalogFilterTable.catalog IS NULL)',
                       ));
        $q->select($modx->getSelectColumns('csFilter','csFilter'));
        $q->select($modx->getSelectColumns('csBrandTable','BrandTable','brandtable_',array('brand'))); 
        $q->select($modx->getSelectColumns('csCategoryTable','CategoryTable','categorytable_',array('category'))); 
//        $q->select($modx->getSelectColumns('csCatalogFilterTable','CatalogFilterTable','catalog_',array('id','catalog'))); 
  //      $q->select($modx->getSelectColumns('csFilterItem','FItem','filteritem_',array('id','name'))); 
//        $q->groupby('id, catalog_catalog'); 
        
        $c=$modx->newQuery('csCatalogFilterTable');
        $c->leftJoin('csFilterItem', 'FilterItem'); 
//        $c->leftJoin('csFilter', 'f','f.id = FilterItem.filter'); 

        $c->where(array(
                'catalog' => $catalog,
            ));
   
         $c->select($modx->getSelectColumns('csCatalogFilterTable','csCatalogFilterTable'));
         $c->select($modx->getSelectColumns('csFilterItem','FilterItem','filteritem_',array('id','name','filter'))); 
 //        $c->select($modx->getSelectColumns('csFilter','f','filter_',array('id','name'))); 

        
        

        $q->prepare();
        $c->prepare();
        
        print "<br /> запрос 1";
        print "<br />". $q->toSQL();
        
        print "<br /> <br /> запрос 2";
        print "<br />". $c->toSQL();
        
        $result = $modx->getCollection('csFilter', $q);
        
        $list1 = array();
        foreach ($result as $object) {
            $res = $object->toArray();
            $list1[] = $res;
        }
        
        print "<table border = 1>";
        $i = true;
        foreach($result as $r){
            $rfromarr = $r->toArray();
            if ($i) {
                foreach($rfromarr as $index => $row){
                    print "<td>";
                    print $index;
                    print "</td>";
                }
                $i = false;
            }
            print "<tr>";
            foreach($rfromarr as $row){
                print "<td>";
                print $row;
                print "</td>";
            }
            print "</tr>";
            }
            
        print "<br> <br> ";
        
        $result = $modx->getCollection('csCatalogFilterTable', $c);
        
        $list2 = array();
        foreach ($result as $object) {
            $res = $object->toArray();
            $list2[] = $res;
            
        }
        print_r ($list2);
        
        print "<table border = 1>";
        $i = true;
        foreach($result as $r){
            $rfromarr = $r->toArray();
            if ($i) {
                foreach($rfromarr as $index => $row){
                    print "<td>";
                    print $index;
                    print "</td>";
                }
                $i = false;
            }
            print "<tr>";
            foreach($rfromarr as $row){
                print "<td>";
                print $row;
                print "</td>";
            }
            print "</tr>";
        }
        
        $array_result = array();
        foreach ($list1 as $row) {
            $result_row = array();
            foreach ($row as $key => $value) {
                $result_row[$key] = $value;
            }
            $el=findrow($list2,$result_row["id"],"filteritem_filter");
            if ( $el >= 0){
                $result_row["filteritem_id"] = $list2[$el]["filteritem_id"];
                $result_row["filteritem_name"] = $list2[$el]["filteritem_name"];
                $result_row["catalog"] = $list2[$el]["catalog"];
            }
            else{
                $result_row["filteritem_id"] = NULL;
                $result_row["filteritem_name"] = NULL;
                $result_row["catalog"] = NULL;
            }
            array_push($array_result, $result_row);
        }
        
        
 //       $array_result = array_intersect($list1, $list2);
         
        print "<table border = 1>";
        $i = true;
        foreach($array_result as $r){
  //          $rfromarr = $r->toArray();
            if ($i) {
                foreach($r as $index => $row){
                    print "<td>";
                    print $index;
                    print "</td>";
                }
                $i = false;
            }
            print "<tr>";
            foreach($r as $row){
                print "<td>";
                print $row;
                print "</td>";
            }
            print "</tr>";
        }
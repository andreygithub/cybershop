<?php
$debug = false;
if ($debug) {
    print 'start snippet <br>';
    };
$cs = $modx->getService('cybershop','Cybershop',$modx->getOption('cybershop.core_path',null,$modx->getOption('core_path').'components/cybershop/').'model/cybershop/',$scriptProperties);
if (!($cs instanceof Cybershop)) { return; }

$categoryid = 0;
if (isset($_GET['categoryid'])){
    $categoryid = $_GET['categoryid'];
    }
    
$tpl = $modx->getOption('tpl',$scriptProperties,'cs.catalog.rowTpl');
$sort = $modx->getOption('sort',$scriptProperties,'name');
$dir = $modx->getOption('dir',$scriptProperties,'ASC');

if ($debug) {
    print 'start query <br>';
    };
$c = $modx->newQuery('csCategory');
$c->where(array(
    'parent' => $parent,
));
$c->sortby($sort,$dir);
$elements = $modx->getCollection('csCategory',$c);

$output = '';
foreach ($elements as $element) {
if ($debug) {
    print 'start intarate <br>';
    print $tpl;
};
    $elementArray = $element->toArray();
    $output .= $cs->getChunk($tpl,$elementArray);
}
if ($debug) {
    print $output;
    };
return $output;
<?php
/**
 * Get a list of Catalog
 *
 * @package cybershop
 * @subpackage processors
 */
class csGetListProcessor extends modObjectGetListProcessor {
    public $classKey = 'csCategory';
    public $languageTopics = array('cybershop:default');
    public $defaultSortField = 'name';
    public $defaultSortDirection = 'ASC';
    public $objectType = 'cs_element';
    
    public function prepareQueryBeforeCount(xPDOQuery $c) {
        if ($this->getProperty('combo')) {
                $c->select('id,name');
                $c->where(array('isfolder' => 0));
        }
        return $c;

    }
    public function outputArray(array $array,$count = false) {
            if ($this->getProperty('addall')) {
                    $array = array_merge_recursive(array(array(
                            'id' => 0
                            ,'name' => $this->modx->lexicon('cs_all')
                    )), $array);
            }
            return parent::outputArray($array, $count);
    }
        
    public function prepareResult(array $resourceArray) {
//            $resourceArray['parents'] = array();
//            $parents = $this->cs->getParentIds('csCategory',$resourceArray['id'], 2, array('context' => $resourceArray['context_key']));
//            if ($parents[count($parents) - 1] == 0) {
//                    unset($parents[count($parents) - 1]);
//            }
//            if (!empty($parents) && is_array($parents)) {
//                    $q = $this->modx->newQuery('csCategory', array('id:IN' => $parents));
//                    $q->select('id,pagetitle');
//                    if ($q->prepare() && $q->stmt->execute()) {
//                            while ($row = $q->stmt->fetch(PDO::FETCH_ASSOC)) {
//                                    $key = array_search($row['id'], $parents);
//                                    if ($key !== false) {
//                                            $parents[$key] = $row;
//                                    }
//                            }
//                    }
//                    $resourceArray['parents'] = array_reverse($parents);
//            }

            return $resourceArray;
    }
}
return 'csGetListProcessor';
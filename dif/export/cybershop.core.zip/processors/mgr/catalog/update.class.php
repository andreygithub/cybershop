<?php
/**
 * @package cybershop
 * @subpackage processors
 */
class csUpdateProcessor extends modObjectUpdateProcessor {
    public $classKey = 'csCatalog';
    public $languageTopics = array('cybershop:default');
    public $objectType = 'cs_element';
    public $permission = 'edit_document';

     
//    public function beforeSave() {
//        $bool = $this->getProperty('active') == 'true' ? 1 : 0; 
//        $this->object->set('active', $bool);
//        $bool = $this->getProperty('deleted') == 'true' ? 1 : 0; 
//        $this->object->set('deleted', $bool);
//        $bool = $this->getProperty('new') == 'true' ? 1 : 0; 
//        $this->object->set('new', $bool);
//        $bool = $this->getProperty('action') == 'true' ? 1 : 0; 
//        $this->object->set('action', $bool);
//        $bool = $this->getProperty('discount') == 'true' ? 1 : 0; 
//        $this->object->set('discount', $bool);
//        $bool = $this->getProperty('onhomepage') == 'true' ? 1 : 0; 
//        $this->object->set('onhomepage', $bool);
//        return !$this->hasErrors();
//    }
    
}
return 'csUpdateProcessor';
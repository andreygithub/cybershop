<?php
/**
 * Get a list of Catalog
 *
 * @package cybershop
 * @subpackage processors
 */
class csGetListProcessor extends modObjectGetListProcessor {
    public $classKey = 'csCatalog';
    public $languageTopics = array('cybershop:default');
    public $defaultSortField = 'name';
    public $defaultSortDirection = 'ASC';
    public $objectType = 'cs_element';
    
    public function prepareQueryBeforeCount(xPDOQuery $c) {
        $c->leftJoin('csBrand', 'Brand');   
        $c->leftJoin('csCategory', 'Category'); 
        $query = $this->getProperty('query');
        if (!empty($query)) {
            $c->where(array(
                'name:LIKE' => '%'.$query.'%',
                'OR:description:LIKE' => '%'.$query.'%',
                'OR:article:LIKE' => '%'.$query.'%',
                'OR:introtext:LIKE' => '%'.$query.'%',
                'OR:fulltext:LIKE' => '%'.$query.'%',
                'OR:made_in:LIKE' => '%'.$query.'%',
            ));
        }
        $brand = $this->getProperty('brand');
        if (!empty($brand)) {
            $c->where(array(
                'brand:LIKE' => '%'.$brand.'%',
            ));
        }
        $category = $this->getProperty('category');
        if (!empty($category)) {
            $c->where(array(
                'category:LIKE' => '%'.$category.'%',
            ));
        }
        return $c;
    }
        
    public function prepareQueryAfterCount(xPDOQuery $c) {
        $c->select($this->modx->getSelectColumns('csCatalog','csCatalog'));
        $c->select($this->modx->getSelectColumns('csBrand','Brand','brand_',array('id','name'))); 
        $c->select($this->modx->getSelectColumns('csCategory','Category','category_',array('id','name')));
        return $c;
    }
}
return 'csGetListProcessor';
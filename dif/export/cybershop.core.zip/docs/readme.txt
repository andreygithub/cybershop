--------------------
Extra: Doodles
--------------------
Version: 1.0
Since: April 20th, 2010
Author: Shaun McCormick <shaun@modx.com>

A simple demo extra for creating robust 3rd-Party Components in MODx Revolution.

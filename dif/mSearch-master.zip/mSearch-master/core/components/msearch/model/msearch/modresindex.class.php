<?php
class ModResIndex extends xPDOSimpleObject {}
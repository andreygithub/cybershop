<?php
require_once (dirname(dirname(__FILE__)) . '/modresindex.class.php');
class ModResIndex_mysql extends ModResIndex {}
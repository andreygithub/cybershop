<?php
/**
 * Resolve creating needed statuses
 *
 * @package cybershop
 * @subpackage build
 */

return true;
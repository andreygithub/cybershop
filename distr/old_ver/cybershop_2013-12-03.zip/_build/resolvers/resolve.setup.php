<?php
/**
 * Resolves setup-options settings
 *
 */
	return true;

<?php
/**
 * Add snippets to build
 * 
 * @package cybershop
 * @subpackage build
 */
$snippets = array();

$snippets['cs_catalog_filter']= $modx->newObject('modSnippet');
$snippets['cs_catalog_filter']->fromArray(array(
	'id' => 0
	,'name' => 'cs_catalog_filter'
	,'description' => 'Фильтрация каталога магазина'
	,'snippet' => getSnippetContent($sources['source_core'].'/elements/snippets/snippet.cs_catalog_filter.php')
	,'static' => 1
	,'static_file' => PKG_NAME_LOWER.'/elements/snippets/snippet.cs_catalog_filter.php'
),'',true,true);

$snippets['cs_element']= $modx->newObject('modSnippet');
$snippets['cs_element']->fromArray(array(
	'id' => 0
	,'name' => 'cs_element'
	,'description' => 'Элемент каталога'
	,'snippet' => getSnippetContent($sources['source_core'].'/elements/snippets/snippet.cs_element.php')
	,'static' => 1
	,'static_file' => PKG_NAME_LOWER.'/elements/snippets/snippet.cs_element.php'
),'',true,true);

$snippets['cs_cabinet']= $modx->newObject('modSnippet');
$snippets['cs_cabinet']->fromArray(array(
	'id' => 0
	,'name' => 'cs_cabinet'
	,'description' => 'Личный кабинет (история покупок пользователя)'
	,'snippet' => getSnippetContent($sources['source_core'].'/elements/snippets/snippet.cs_cabinet.php')
	,'static' => 1
	,'static_file' => PKG_NAME_LOWER.'/elements/snippets/snippet.cs_cabinet.php'
),'',true,true);

$snippets['cs_categorys']= $modx->newObject('modSnippet');
$snippets['cs_categorys']->fromArray(array(
	'id' => 0
	,'name' => 'cs_categorys'
	,'description' => 'Вывод категорий каталога'
	,'snippet' => getSnippetContent($sources['source_core'].'/elements/snippets/snippet.cs_categorys.php')
	,'static' => 1
	,'static_file' => PKG_NAME_LOWER.'/elements/snippets/snippet.cs_categorys.php'
),'',true,true);

$snippets['cs_shop_cart']= $modx->newObject('modSnippet');
$snippets['cs_shop_cart']->fromArray(array(
	'id' => 0
	,'name' => 'cs_shop_cart'
	,'description' => 'Вывод корзины покупок'
	,'snippet' => getSnippetContent($sources['source_core'].'/elements/snippets/snippet.cs_shop_cart.php')
	,'static' => 1
	,'static_file' => PKG_NAME_LOWER.'/elements/snippets/snippet.cs_shop_cart.php'
),'',true,true);

$snippets['cs_shop_minicard']= $modx->newObject('modSnippet');
$snippets['cs_shop_minicard']->fromArray(array(
	'id' => 0
	,'name' => 'cs_shop_minicard'
	,'description' => 'Вывод статуса корзины'
	,'snippet' => getSnippetContent($sources['source_core'].'/elements/snippets/snippet.cs_shop_minicard.php')
	,'static' => 1
	,'static_file' => PKG_NAME_LOWER.'/elements/snippets/snippet.cs_shop_minicard.php'
),'',true,true);

$snippets['cs_shop_order']= $modx->newObject('modSnippet');
$snippets['cs_shop_order']->fromArray(array(
	'id' => 0
	,'name' => 'cs_shop_order'
	,'description' => 'Оформление заказа'
	,'snippet' => getSnippetContent($sources['source_core'].'/elements/snippets/snippet.cs_shop_order.php')
	,'static' => 1
	,'static_file' => PKG_NAME_LOWER.'/elements/snippets/snippet.cs_shop_order.php'
),'',true,true);

return $snippets;

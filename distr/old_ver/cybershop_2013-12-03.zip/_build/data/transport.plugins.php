<?php
/**
 * Package in plugins
 *
 * @package cybershop
 * @subpackage build
 */
$plugins = array();

return $plugins;
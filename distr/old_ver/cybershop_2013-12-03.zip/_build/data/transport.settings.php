<?php
/**
 * Loads system settings into build
 *
 * @package cybershop
 * @subpackage build
 */
$settings = array();

$tmp = array(
	'cybershop.email_manager' => array(
		'value' => 'andreyzagorets@gmail.com'
		,'xtype' => 'textfield'
		,'area' => ''
	)
	,'cybershop.catalog_image_path' => array(
		'value' => 'upload/catalog/images/'
		,'xtype' => 'textfield'
		,'area' => ''
	)
	,'cybershop.catalog_media_path' => array(
		'value' => 'upload/catalog/media/'
		,'xtype' => 'textfield'
		,'area' => ''
	)    
	,'cybershop.catalog_import_path' => array(
		'value' => 'upload/catalog/import/'
		,'xtype' => 'textfield'
		,'area' => ''
	)
	,'cybershop.import_delimiter' => array(
		'value' => ';'
		,'xtype' => 'textfield'
		,'area' => ''
	)
    	,'cybershop.price_format' => array(
		'value' => '[2, ".", " "]'
		,'xtype' => 'textfield'
		,'area' => ''
	)	
        ,'cybershop.price_format_no_zeros' => array(
		'value' => true
		,'xtype' => 'combo-boolean'
		,'area' => ''
	)	
        ,'cybershop.weight_format' => array(
		'value' => '[3, ".", " "]'
		,'xtype' => 'textfield'
		,'area' => ''
	)
        ,'cybershop.weight_format_no_zeros' => array(
		'value' => true
		,'xtype' => 'combo-boolean'
		,'area' => ''
	)    
);


foreach ($tmp as $k => $v) {
	/* @var modSystemSetting $setting */
	$setting = $modx->newObject('modSystemSetting');
	$setting->fromArray(array_merge(
		array(
			'key' => $k
			,'namespace' => 'cybershop'
		), $v
	),'',true,true);

	$settings[] = $setting;
}

return $settings;
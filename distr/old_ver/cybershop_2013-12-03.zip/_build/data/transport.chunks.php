<?php
/**
 * Add chunks to build
 * 
 * @package cybershop
 * @subpackage build
 */
$chunks = array();

$chunks['cs_tpl_cabinet_main']= $modx->newObject('modChunk');
$chunks['cs_tpl_cabinet_main']->fromArray(array(
	'id' => 0,
	'name' => 'cs_tpl_cabinet_main',
	'description' => '',
	'snippet' => file_get_contents($sources['source_core'].'/elements/chunks/cs_tpl_cabinet_main.chunk.tpl'),
	'static_file' => PKG_NAME_LOWER.'/elements/chunks/cs_tpl_cabinet_main.chunk.tpl'
),'',true,true);

$chunks['cs_tpl_cabinet_row']= $modx->newObject('modChunk');
$chunks['cs_tpl_cabinet_row']->fromArray(array(
	'id' => 0,
	'name' => 'cs_tpl_cabinet_row',
	'description' => '',
	'snippet' => file_get_contents($sources['source_core'].'/elements/chunks/cs_tpl_cabinet_row.chunk.tpl'),
	'static_file' => PKG_NAME_LOWER.'/elements/chunks/cs_tpl_cabinet_row.chunk.tpl'
),'',true,true);

$chunks['cs_tpl_catalog_row']= $modx->newObject('modChunk');
$chunks['cs_tpl_catalog_row']->fromArray(array(
	'id' => 0,
	'name' => 'cs_tpl_catalog_row',
	'description' => '',
	'snippet' => file_get_contents($sources['source_core'].'/elements/chunks/cs_tpl_catalog_row.chunk.tpl'),
	'static_file' => PKG_NAME_LOWER.'/elements/chunks/cs_tpl_catalog_row.chunk.tpl'
),'',true,true);

$chunks['cs_tpl_catalog_main']= $modx->newObject('modChunk');
$chunks['cs_tpl_catalog_main']->fromArray(array(
	'id' => 0,
	'name' => 'cs_tpl_catalog_main',
	'description' => '',
	'snippet' => file_get_contents($sources['source_core'].'/elements/chunks/cs_tpl_catalog_main.chunk.tpl'),
	'static_file' => PKG_NAME_LOWER.'/elements/chunks/cs_tpl_catalog_main.chunk.tpl'
),'',true,true);

$chunks['cs_tpl_catalog_nav_block']= $modx->newObject('modChunk');
$chunks['cs_tpl_catalog_nav_block']->fromArray(array(
	'id' => 0,
	'name' => 'cs_tpl_catalog_nav_block',
	'description' => '',
	'snippet' => file_get_contents($sources['source_core'].'/elements/chunks/cs_tpl_catalog_nav_block.chunk.tpl'),
	'static_file' => PKG_NAME_LOWER.'/elements/chunks/cs_tpl_catalog_nav_block.chunk.tpl'
),'',true,true);

$chunks['cs_tpl_catalog_nav_row']= $modx->newObject('modChunk');
$chunks['cs_tpl_catalog_nav_row']->fromArray(array(
	'id' => 0,
	'name' => 'cs_tpl_catalog_nav_row',
	'description' => '',
	'snippet' => file_get_contents($sources['source_core'].'/elements/chunks/cs_tpl_catalog_nav_row.chunk.tpl'),
	'static_file' => PKG_NAME_LOWER.'/elements/chunks/cs_tpl_catalog_nav_row.chunk.tpl'
),'',true,true);

$chunks['cs_tpl_category_row']= $modx->newObject('modChunk');
$chunks['cs_tpl_category_row']->fromArray(array(
	'id' => 0,
	'name' => 'cs_tpl_category_row',
	'description' => '',
	'snippet' => file_get_contents($sources['source_core'].'/elements/chunks/cs_tpl_category_row.chunk.tpl'),
	'static_file' => PKG_NAME_LOWER.'/elements/chunks/cs_tpl_category_row.chunk.tpl'
),'',true,true);

$chunks['cs_tpl_category_main']= $modx->newObject('modChunk');
$chunks['cs_tpl_category_main']->fromArray(array(
	'id' => 0,
	'name' => 'cs_tpl_category_main',
	'description' => '',
	'snippet' => file_get_contents($sources['source_core'].'/elements/chunks/cs_tpl_category_main.chunk.tpl'),
	'static_file' => PKG_NAME_LOWER.'/elements/chunks/cs_tpl_category_main.chunk.tpl'
),'',true,true);

$chunks['cs_tpl_category_row']= $modx->newObject('modChunk');
$chunks['cs_tpl_category_row']->fromArray(array(
	'id' => 0,
	'name' => 'cs_tpl_category_row',
	'description' => '',
	'snippet' => file_get_contents($sources['source_core'].'/elements/chunks/cs_tpl_category_row.chunk.tpl'),
	'static_file' => PKG_NAME_LOWER.'/elements/chunks/cs_tpl_category_row.chunk.tpl'
),'',true,true);

$chunks['cs_tpl_element_complect_row']= $modx->newObject('modChunk');
$chunks['cs_tpl_element_complect_row']->fromArray(array(
	'id' => 0,
	'name' => 'cs_tpl_element_complect_row',
	'description' => '',
	'snippet' => file_get_contents($sources['source_core'].'/elements/chunks/cs_tpl_element_complect_row.chunk.tpl'),
	'static_file' => PKG_NAME_LOWER.'/elements/chunks/cs_tpl_element_complect_row.chunk.tpl'
),'',true,true);

$chunks['cs_tpl_element_foto']= $modx->newObject('modChunk');
$chunks['cs_tpl_element_foto']->fromArray(array(
	'id' => 0,
	'name' => 'cs_tpl_element_foto',
	'description' => '',
	'snippet' => file_get_contents($sources['source_core'].'/elements/chunks/cs_tpl_element_foto.chunk.tpl'),
	'static_file' => PKG_NAME_LOWER.'/elements/chunks/cs_tpl_element_foto.chunk.tpl'
),'',true,true);

$chunks['cs_tpl_element_main']= $modx->newObject('modChunk');
$chunks['cs_tpl_element_main']->fromArray(array(
	'id' => 0,
	'name' => 'cs_tpl_element_main',
	'description' => '',
	'snippet' => file_get_contents($sources['source_core'].'/elements/chunks/cs_tpl_element_main.chunk.tpl'),
	'static_file' => PKG_NAME_LOWER.'/elements/chunks/cs_tpl_element_main.chunk.tpl'
),'',true,true);

$chunks['cs_tpl_pagination_main']= $modx->newObject('modChunk');
$chunks['cs_tpl_pagination_main']->fromArray(array(
	'id' => 0,
	'name' => 'cs_tpl_pagination_main',
	'description' => '',
	'snippet' => file_get_contents($sources['source_core'].'/elements/chunks/cs_tpl_pagination_main.chunk.tpl'),
	'static_file' => PKG_NAME_LOWER.'/elements/chunks/cs_tpl_pagination_main.chunk.tpl'
),'',true,true);

$chunks['cs_tpl_pagination_row']= $modx->newObject('modChunk');
$chunks['cs_tpl_pagination_row']->fromArray(array(
	'id' => 0,
	'name' => 'cs_tpl_pagination_row',
	'description' => '',
	'snippet' => file_get_contents($sources['source_core'].'/elements/chunks/cs_tpl_pagination_row.chunk.tpl'),
	'static_file' => PKG_NAME_LOWER.'/elements/chunks/cs_tpl_pagination_row.chunk.tpl'
),'',true,true);

$chunks['cs_tpl_shop_card_main']= $modx->newObject('modChunk');
$chunks['cs_tpl_shop_card_main']->fromArray(array(
	'id' => 0,
	'name' => 'cs_tpl_shop_card_main',
	'description' => '',
	'snippet' => file_get_contents($sources['source_core'].'/elements/chunks/cs_tpl_shop_card_main.chunk.tpl'),
	'static_file' => PKG_NAME_LOWER.'/elements/chunks/cs_tpl_shop_card_main.chunk.tpl'
),'',true,true);

$chunks['cs_tpl_shop_card_row']= $modx->newObject('modChunk');
$chunks['cs_tpl_shop_card_row']->fromArray(array(
	'id' => 0,
	'name' => 'cs_tpl_shop_card_row',
	'description' => '',
	'snippet' => file_get_contents($sources['source_core'].'/elements/chunks/cs_tpl_shop_card_row.chunk.tpl'),
	'static_file' => PKG_NAME_LOWER.'/elements/chunks/cs_tpl_shop_card_row.chunk.tpl'
),'',true,true);

$chunks['cs_tpl_shop_minicard']= $modx->newObject('modChunk');
$chunks['cs_tpl_shop_minicard']->fromArray(array(
	'id' => 0,
	'name' => 'cs_tpl_shop_minicard',
	'description' => '',
	'snippet' => file_get_contents($sources['source_core'].'/elements/chunks/cs_tpl_shop_minicard.chunk.tpl'),
	'static_file' => PKG_NAME_LOWER.'/elements/chunks/cs_tpl_shop_minicard.chunk.tpl'
),'',true,true);

$chunks['cs_tpl_shop_order']= $modx->newObject('modChunk');
$chunks['cs_tpl_shop_order']->fromArray(array(
	'id' => 0,
	'name' => 'cs_tpl_shop_order',
	'description' => '',
	'snippet' => file_get_contents($sources['source_core'].'/elements/chunks/cs_tpl_shop_order.chunk.tpl'),
	'static_file' => PKG_NAME_LOWER.'/elements/chunks/cs_tpl_shop_order.chunk.tpl'
),'',true,true);

return $chunks;
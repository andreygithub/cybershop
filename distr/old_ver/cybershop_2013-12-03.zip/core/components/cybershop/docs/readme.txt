--------------------
Extra: Cybershop
--------------------
Version: 1.1 beta
Since: September 2013
Author: Andrey Zagorets <AndreyZagorets@gmail.com>

Простой и удобный интернет магазин

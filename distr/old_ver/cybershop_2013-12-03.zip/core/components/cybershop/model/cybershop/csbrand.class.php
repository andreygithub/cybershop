<?php
class csBrand extends xPDOSimpleObject {}
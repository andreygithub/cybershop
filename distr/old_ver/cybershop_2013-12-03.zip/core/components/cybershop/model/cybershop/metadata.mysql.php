<?php

$xpdo_meta_map = array (
  'xPDOSimpleObject' => 
  array (
    0 => 'csCatalog',
    1 => 'csCatalogFilterTable',
    2 => 'csCatalogPropertyTable',
    3 => 'csCatalogImageTable',
    4 => 'csCatalogComplectTable',
    5 => 'csCatalogSimilarTable',
    6 => 'csCatalogStoreTable',
    7 => 'csBrand',
    8 => 'csBrandTable',
    9 => 'csBrandPropertyTable',
    10 => 'csCategory',
    11 => 'csCategoryTable',
    12 => 'csCategoryPropertyTable',
    13 => 'csFilter',
    14 => 'csFilterItem',
    15 => 'csProperty',
    16 => 'csStore',
    17 => 'csDelivery',
    18 => 'csPayment',
    19 => 'csCurrency',
    20 => 'csOrder',
    21 => 'csOrderStatus',
    22 => 'csOrderLog',
    23 => 'csOrderAddress',
    24 => 'csOrderProduct',
  ),
);
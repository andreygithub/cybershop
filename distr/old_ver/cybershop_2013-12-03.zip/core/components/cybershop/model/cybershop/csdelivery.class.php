<?php
class csDelivery extends xPDOSimpleObject {}
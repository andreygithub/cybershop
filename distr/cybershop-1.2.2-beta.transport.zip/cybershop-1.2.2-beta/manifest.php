<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'changelog' => 'Changelog file for Cybershop component.

Cybershop 1.2.1 beta
====================================
- Updates and remove some bugs

Cybershop 1.1 beta
====================================
- Updates 

Cybershop 1.0 beta
====================================
- Updates',
    'license' => 'GNU GENERAL PUBLIC LICENSE
   Version 2, June 1991
--------------------------

Copyright (C) 1989, 1991 Free Software Foundation, Inc.
59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

Everyone is permitted to copy and distribute verbatim copies
of this license document, but changing it is not allowed.

Preamble
--------

  The licenses for most software are designed to take away your
freedom to share and change it.  By contrast, the GNU General Public
License is intended to guarantee your freedom to share and change free
software--to make sure the software is free for all its users.  This
General Public License applies to most of the Free Software
Foundation\'s software and to any other program whose authors commit to
using it.  (Some other Free Software Foundation software is covered by
the GNU Library General Public License instead.)  You can apply it to
your programs, too.

  When we speak of free software, we are referring to freedom, not
price.  Our General Public Licenses are designed to make sure that you
have the freedom to distribute copies of free software (and charge for
this service if you wish), that you receive source code or can get it
if you want it, that you can change the software or use pieces of it
in new free programs; and that you know you can do these things.

  To protect your rights, we need to make restrictions that forbid
anyone to deny you these rights or to ask you to surrender the rights.
These restrictions translate to certain responsibilities for you if you
distribute copies of the software, or if you modify it.

  For example, if you distribute copies of such a program, whether
gratis or for a fee, you must give the recipients all the rights that
you have.  You must make sure that they, too, receive or can get the
source code.  And you must show them these terms so they know their
rights.

  We protect your rights with two steps: (1) copyright the software, and
(2) offer you this license which gives you legal permission to copy,
distribute and/or modify the software.

  Also, for each author\'s protection and ours, we want to make certain
that everyone understands that there is no warranty for this free
software.  If the software is modified by someone else and passed on, we
want its recipients to know that what they have is not the original, so
that any problems introduced by others will not reflect on the original
authors\' reputations.

  Finally, any free program is threatened constantly by software
patents.  We wish to avoid the danger that redistributors of a free
program will individually obtain patent licenses, in effect making the
program proprietary.  To prevent this, we have made it clear that any
patent must be licensed for everyone\'s free use or not licensed at all.

  The precise terms and conditions for copying, distribution and
modification follow.


GNU GENERAL PUBLIC LICENSE
TERMS AND CONDITIONS FOR COPYING, DISTRIBUTION AND MODIFICATION
---------------------------------------------------------------

  0. This License applies to any program or other work which contains
a notice placed by the copyright holder saying it may be distributed
under the terms of this General Public License.  The "Program", below,
refers to any such program or work, and a "work based on the Program"
means either the Program or any derivative work under copyright law:
that is to say, a work containing the Program or a portion of it,
either verbatim or with modifications and/or translated into another
language.  (Hereinafter, translation is included without limitation in
the term "modification".)  Each licensee is addressed as "you".

Activities other than copying, distribution and modification are not
covered by this License; they are outside its scope.  The act of
running the Program is not restricted, and the output from the Program
is covered only if its contents constitute a work based on the
Program (independent of having been made by running the Program).
Whether that is true depends on what the Program does.

  1. You may copy and distribute verbatim copies of the Program\'s
source code as you receive it, in any medium, provided that you
conspicuously and appropriately publish on each copy an appropriate
copyright notice and disclaimer of warranty; keep intact all the
notices that refer to this License and to the absence of any warranty;
and give any other recipients of the Program a copy of this License
along with the Program.

You may charge a fee for the physical act of transferring a copy, and
you may at your option offer warranty protection in exchange for a fee.

  2. You may modify your copy or copies of the Program or any portion
of it, thus forming a work based on the Program, and copy and
distribute such modifications or work under the terms of Section 1
above, provided that you also meet all of these conditions:

    a) You must cause the modified files to carry prominent notices
    stating that you changed the files and the date of any change.

    b) You must cause any work that you distribute or publish, that in
    whole or in part contains or is derived from the Program or any
    part thereof, to be licensed as a whole at no charge to all third
    parties under the terms of this License.

    c) If the modified program normally reads commands interactively
    when run, you must cause it, when started running for such
    interactive use in the most ordinary way, to print or display an
    announcement including an appropriate copyright notice and a
    notice that there is no warranty (or else, saying that you provide
    a warranty) and that users may redistribute the program under
    these conditions, and telling the user how to view a copy of this
    License.  (Exception: if the Program itself is interactive but
    does not normally print such an announcement, your work based on
    the Program is not required to print an announcement.)

These requirements apply to the modified work as a whole.  If
identifiable sections of that work are not derived from the Program,
and can be reasonably considered independent and separate works in
themselves, then this License, and its terms, do not apply to those
sections when you distribute them as separate works.  But when you
distribute the same sections as part of a whole which is a work based
on the Program, the distribution of the whole must be on the terms of
this License, whose permissions for other licensees extend to the
entire whole, and thus to each and every part regardless of who wrote it.

Thus, it is not the intent of this section to claim rights or contest
your rights to work written entirely by you; rather, the intent is to
exercise the right to control the distribution of derivative or
collective works based on the Program.

In addition, mere aggregation of another work not based on the Program
with the Program (or with a work based on the Program) on a volume of
a storage or distribution medium does not bring the other work under
the scope of this License.

  3. You may copy and distribute the Program (or a work based on it,
under Section 2) in object code or executable form under the terms of
Sections 1 and 2 above provided that you also do one of the following:

    a) Accompany it with the complete corresponding machine-readable
    source code, which must be distributed under the terms of Sections
    1 and 2 above on a medium customarily used for software interchange; or,

    b) Accompany it with a written offer, valid for at least three
    years, to give any third party, for a charge no more than your
    cost of physically performing source distribution, a complete
    machine-readable copy of the corresponding source code, to be
    distributed under the terms of Sections 1 and 2 above on a medium
    customarily used for software interchange; or,

    c) Accompany it with the information you received as to the offer
    to distribute corresponding source code.  (This alternative is
    allowed only for noncommercial distribution and only if you
    received the program in object code or executable form with such
    an offer, in accord with Subsection b above.)

The source code for a work means the preferred form of the work for
making modifications to it.  For an executable work, complete source
code means all the source code for all modules it contains, plus any
associated interface definition files, plus the scripts used to
control compilation and installation of the executable.  However, as a
special exception, the source code distributed need not include
anything that is normally distributed (in either source or binary
form) with the major components (compiler, kernel, and so on) of the
operating system on which the executable runs, unless that component
itself accompanies the executable.

If distribution of executable or object code is made by offering
access to copy from a designated place, then offering equivalent
access to copy the source code from the same place counts as
distribution of the source code, even though third parties are not
compelled to copy the source along with the object code.

  4. You may not copy, modify, sublicense, or distribute the Program
except as expressly provided under this License.  Any attempt
otherwise to copy, modify, sublicense or distribute the Program is
void, and will automatically terminate your rights under this License.
However, parties who have received copies, or rights, from you under
this License will not have their licenses terminated so long as such
parties remain in full compliance.

  5. You are not required to accept this License, since you have not
signed it.  However, nothing else grants you permission to modify or
distribute the Program or its derivative works.  These actions are
prohibited by law if you do not accept this License.  Therefore, by
modifying or distributing the Program (or any work based on the
Program), you indicate your acceptance of this License to do so, and
all its terms and conditions for copying, distributing or modifying
the Program or works based on it.

  6. Each time you redistribute the Program (or any work based on the
Program), the recipient automatically receives a license from the
original licensor to copy, distribute or modify the Program subject to
these terms and conditions.  You may not impose any further
restrictions on the recipients\' exercise of the rights granted herein.
You are not responsible for enforcing compliance by third parties to
this License.

  7. If, as a consequence of a court judgment or allegation of patent
infringement or for any other reason (not limited to patent issues),
conditions are imposed on you (whether by court order, agreement or
otherwise) that contradict the conditions of this License, they do not
excuse you from the conditions of this License.  If you cannot
distribute so as to satisfy simultaneously your obligations under this
License and any other pertinent obligations, then as a consequence you
may not distribute the Program at all.  For example, if a patent
license would not permit royalty-free redistribution of the Program by
all those who receive copies directly or indirectly through you, then
the only way you could satisfy both it and this License would be to
refrain entirely from distribution of the Program.

If any portion of this section is held invalid or unenforceable under
any particular circumstance, the balance of the section is intended to
apply and the section as a whole is intended to apply in other
circumstances.

It is not the purpose of this section to induce you to infringe any
patents or other property right claims or to contest validity of any
such claims; this section has the sole purpose of protecting the
integrity of the free software distribution system, which is
implemented by public license practices.  Many people have made
generous contributions to the wide range of software distributed
through that system in reliance on consistent application of that
system; it is up to the author/donor to decide if he or she is willing
to distribute software through any other system and a licensee cannot
impose that choice.

This section is intended to make thoroughly clear what is believed to
be a consequence of the rest of this License.

  8. If the distribution and/or use of the Program is restricted in
certain countries either by patents or by copyrighted interfaces, the
original copyright holder who places the Program under this License
may add an explicit geographical distribution limitation excluding
those countries, so that distribution is permitted only in or among
countries not thus excluded.  In such case, this License incorporates
the limitation as if written in the body of this License.

  9. The Free Software Foundation may publish revised and/or new versions
of the General Public License from time to time.  Such new versions will
be similar in spirit to the present version, but may differ in detail to
address new problems or concerns.

Each version is given a distinguishing version number.  If the Program
specifies a version number of this License which applies to it and "any
later version", you have the option of following the terms and conditions
either of that version or of any later version published by the Free
Software Foundation.  If the Program does not specify a version number of
this License, you may choose any version ever published by the Free Software
Foundation.

  10. If you wish to incorporate parts of the Program into other free
programs whose distribution conditions are different, write to the author
to ask for permission.  For software which is copyrighted by the Free
Software Foundation, write to the Free Software Foundation; we sometimes
make exceptions for this.  Our decision will be guided by the two goals
of preserving the free status of all derivatives of our free software and
of promoting the sharing and reuse of software generally.

NO WARRANTY
-----------

  11. BECAUSE THE PROGRAM IS LICENSED FREE OF CHARGE, THERE IS NO WARRANTY
FOR THE PROGRAM, TO THE EXTENT PERMITTED BY APPLICABLE LAW.  EXCEPT WHEN
OTHERWISE STATED IN WRITING THE COPYRIGHT HOLDERS AND/OR OTHER PARTIES
PROVIDE THE PROGRAM "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED
OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.  THE ENTIRE RISK AS
TO THE QUALITY AND PERFORMANCE OF THE PROGRAM IS WITH YOU.  SHOULD THE
PROGRAM PROVE DEFECTIVE, YOU ASSUME THE COST OF ALL NECESSARY SERVICING,
REPAIR OR CORRECTION.

  12. IN NO EVENT UNLESS REQUIRED BY APPLICABLE LAW OR AGREED TO IN WRITING
WILL ANY COPYRIGHT HOLDER, OR ANY OTHER PARTY WHO MAY MODIFY AND/OR
REDISTRIBUTE THE PROGRAM AS PERMITTED ABOVE, BE LIABLE TO YOU FOR DAMAGES,
INCLUDING ANY GENERAL, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES ARISING
OUT OF THE USE OR INABILITY TO USE THE PROGRAM (INCLUDING BUT NOT LIMITED
TO LOSS OF DATA OR DATA BEING RENDERED INACCURATE OR LOSSES SUSTAINED BY
YOU OR THIRD PARTIES OR A FAILURE OF THE PROGRAM TO OPERATE WITH ANY OTHER
PROGRAMS), EVEN IF SUCH HOLDER OR OTHER PARTY HAS BEEN ADVISED OF THE
POSSIBILITY OF SUCH DAMAGES.

---------------------------
END OF TERMS AND CONDITIONS',
    'readme' => '--------------------
Extra: Cybershop
--------------------
Version: 1.1 beta
Since: September 2013
Author: Andrey Zagorets <AndreyZagorets@gmail.com>

Простой и удобный интернет магазин

Для работы с ЧПУ обязательно добавить в .htaccess

RewriteCond %{REQUEST_FILENAME} !-f
RewriteCond %{REQUEST_FILENAME} !-d
RewriteRule ^catalog/element/(.*)$ index.php?q=catalog/element&elementid=$1 [L,QSA]
RewriteRule ^catalog/get/(.*)$ index.php?q=catalog/get&categorysgroup=$1 [L,QSA]
',
    'setup-options' => 'cybershop-1.2.2-beta/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '512af94c3d0b238ea0d07a094fac4e74',
      'native_key' => 'cybershop',
      'filename' => 'modNamespace/e360a167164df575c3f83a4f8d287d41.vehicle',
      'namespace' => 'cybershop',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'af32af9a90ab271f862544278d1f3c03',
      'native_key' => 'cybershop.email_manager',
      'filename' => 'modSystemSetting/4431810068201b0db6c75cf29479e3ef.vehicle',
      'namespace' => 'cybershop',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '64e35b476a5563d15fdc3318eeae4e2f',
      'native_key' => 'cybershop.order_user_groups',
      'filename' => 'modSystemSetting/95c79518ec5bd72bb9122b6a6a3b65a0.vehicle',
      'namespace' => 'cybershop',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0feb9760f78d8267531917d0d64f53be',
      'native_key' => 'cybershop.catalog_image_path',
      'filename' => 'modSystemSetting/d8244b48ff30066d843cb58563644af9.vehicle',
      'namespace' => 'cybershop',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd92c85f0c08b0491856d8c81826f9254',
      'native_key' => 'cybershop.catalog_media_path',
      'filename' => 'modSystemSetting/fc5b8bc2e110d0b998bf94faa9b200be.vehicle',
      'namespace' => 'cybershop',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ff44c9ba899d38a8c3bd3f4f32ca20af',
      'native_key' => 'cybershop.catalog_import_path',
      'filename' => 'modSystemSetting/413a27d062aa7aa68e79732a337c5dde.vehicle',
      'namespace' => 'cybershop',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6d475ce025b0700f6e86f4e0af8577c9',
      'native_key' => 'cybershop.import_delimiter',
      'filename' => 'modSystemSetting/6e75c2d720cb985a7c7963c0fb0e35ec.vehicle',
      'namespace' => 'cybershop',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '975600b7c7fc6c48313650f6b2969be9',
      'native_key' => 'cybershop.catalog_categorysgroup',
      'filename' => 'modSystemSetting/48d760d511a433c78e96a28378dd512c.vehicle',
      'namespace' => 'cybershop',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cbeeb98e64cfa8cddf5e13cd7e446476',
      'native_key' => 'cybershop.catalog_categorys',
      'filename' => 'modSystemSetting/0884af069b24407476f4613a5a5d3bdd.vehicle',
      'namespace' => 'cybershop',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6261fe2a65598b4ba5a55aac3ad34776',
      'native_key' => 'cybershop.catalog_brands',
      'filename' => 'modSystemSetting/845dbd58421aa4f5191494dd98a0aa94.vehicle',
      'namespace' => 'cybershop',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '625ae98b913681568ea3824264aabb7e',
      'native_key' => 'cybershop.catalog_filters',
      'filename' => 'modSystemSetting/867a103acb2d5498e144db987f72ae39.vehicle',
      'namespace' => 'cybershop',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '91ad9ed944b0e9f65a1650d739798643',
      'native_key' => 'cybershop.catalog_pricemin',
      'filename' => 'modSystemSetting/06856c8b08984d3e952b063575f1120c.vehicle',
      'namespace' => 'cybershop',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '91d1d021fc0c52e0751c9ad441ec9fa5',
      'native_key' => 'cybershop.catalog_pricemax',
      'filename' => 'modSystemSetting/24465e88d5533f69f45cde498e755015.vehicle',
      'namespace' => 'cybershop',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b8c9e8a6bbce1b12c8db266954465acd',
      'native_key' => 'cybershop.catalog_limit',
      'filename' => 'modSystemSetting/3383c540e5fbfc58e8c6d0a6d56d5fd6.vehicle',
      'namespace' => 'cybershop',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bb683f99776bdb392766fbfeb236db43',
      'native_key' => 'cybershop.catalog_sortname',
      'filename' => 'modSystemSetting/3804cd47a7991baded64c1b2ddd42918.vehicle',
      'namespace' => 'cybershop',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4110a1b4e611fd6ad71ad36fdcb7becd',
      'native_key' => 'cybershop.catalog_sortdirection',
      'filename' => 'modSystemSetting/c6e218bbe835985987d5ad61ef549c93.vehicle',
      'namespace' => 'cybershop',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a017729e56e473351f4e720572934222',
      'native_key' => 'cybershop.catalog_index_fields',
      'filename' => 'modSystemSetting/2d387f13ddff167a17b94433fcc6e2b1.vehicle',
      'namespace' => 'cybershop',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ed42e67b2e7707b516703484a4a435b7',
      'native_key' => 'cybershop.currency',
      'filename' => 'modSystemSetting/edac359cd89651283046030ab9a74003.vehicle',
      'namespace' => 'cybershop',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ee5fd536c1c5cc810a056f564550419d',
      'native_key' => 'cybershop.price_format',
      'filename' => 'modSystemSetting/bce1d594dfdad429210e0ba1f64e6d9c.vehicle',
      'namespace' => 'cybershop',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '36cc333a3dd40e0ed7e3840cd4a3b772',
      'native_key' => 'cybershop.price_format_no_zeros',
      'filename' => 'modSystemSetting/99a70958c6f2f5d5c35fbe9e97181de6.vehicle',
      'namespace' => 'cybershop',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '45fa0c0c1f545cea5c8e840c278d539e',
      'native_key' => 'cybershop.weight_format',
      'filename' => 'modSystemSetting/22bbbaa3cdd0d42699af838d137909dd.vehicle',
      'namespace' => 'cybershop',
    ),
    21 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f30e7e55f048a71c32e0f9b5339ef694',
      'native_key' => 'cybershop.weight_format_no_zeros',
      'filename' => 'modSystemSetting/cd94bad5fc760a0887bfe41f8c7795a1.vehicle',
      'namespace' => 'cybershop',
    ),
    22 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f30726188e8fbb010053fd31121f2ef1',
      'native_key' => 'cybershop.res_catalog_element_id',
      'filename' => 'modSystemSetting/3075275740d5cad1da4d8f325ae3ccd7.vehicle',
      'namespace' => 'cybershop',
    ),
    23 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '89b241249bee302a4ae809b634fb275f',
      'native_key' => 'cybershop.res_catalog_get_id',
      'filename' => 'modSystemSetting/98336728bebb2868c8dd046989733ee4.vehicle',
      'namespace' => 'cybershop',
    ),
    24 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5794b783abf39badcb3be20184e8008e',
      'native_key' => 'cybershop.res_catalog_id',
      'filename' => 'modSystemSetting/7b99fd9df2a0c6d84d96a81693a9ee5d.vehicle',
      'namespace' => 'cybershop',
    ),
    25 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2ad9a31f60c15f92738ee4812c2db518',
      'native_key' => 'cybershop.res_cart_id',
      'filename' => 'modSystemSetting/4196a3317757a806e6e773c7dff1968f.vehicle',
      'namespace' => 'cybershop',
    ),
    26 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '219831628ab300e709dc365016748b9b',
      'native_key' => 'cybershop.res_cart_order_id',
      'filename' => 'modSystemSetting/ee14ad0d6bf10fed30f0dfbd63e0fd5e.vehicle',
      'namespace' => 'cybershop',
    ),
    27 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0d4e3aad6f32ff7470d9f8cb7da9e4e0',
      'native_key' => 'cybershop.res_cart_order_result_id',
      'filename' => 'modSystemSetting/3c04b2eb1e86763a8dcbc8e271ba20cf.vehicle',
      'namespace' => 'cybershop',
    ),
    28 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3518d35e22a090112a733082a6697790',
      'native_key' => 'csOnBeforeAddToCart',
      'filename' => 'modEvent/254b7421de0271fcbf415f37db47ad96.vehicle',
      'namespace' => 'cybershop',
    ),
    29 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '98d030160ac52390d5190838fc9b02e6',
      'native_key' => 'csOnAddToCart',
      'filename' => 'modEvent/89d40d21356eb18ce47827176615ccc5.vehicle',
      'namespace' => 'cybershop',
    ),
    30 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'eefabc4f49ff4d9a36394aed712c3b59',
      'native_key' => 'csOnBeforeChangeInCart',
      'filename' => 'modEvent/8c5221baf42e2a19677743e13178f83f.vehicle',
      'namespace' => 'cybershop',
    ),
    31 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'abd0c9e92c60264dea9daf81bf0b45f1',
      'native_key' => 'csOnChangeInCart',
      'filename' => 'modEvent/5c12631f6ddb44b164f09dd3d51d5978.vehicle',
      'namespace' => 'cybershop',
    ),
    32 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '32eb2097d2c59fc0640017a827f1afae',
      'native_key' => 'csOnBeforeRemoveFromCart',
      'filename' => 'modEvent/b050d358d6cd80e5c93347c8d48e1a5a.vehicle',
      'namespace' => 'cybershop',
    ),
    33 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9af65c1a45f9875cd92a5ef028e3d0a6',
      'native_key' => 'csOnRemoveFromCart',
      'filename' => 'modEvent/3c22fd5a6fccffa35c7b7a24e915a792.vehicle',
      'namespace' => 'cybershop',
    ),
    34 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '44129bcec49437dcd99d9d0c6b9e6eff',
      'native_key' => 'csOnBeforeEmptyCart',
      'filename' => 'modEvent/b445d9c92f9c8865f149cdde739c1f74.vehicle',
      'namespace' => 'cybershop',
    ),
    35 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fc8e8ecf23b80066a251d23418040267',
      'native_key' => 'csOnEmptyCart',
      'filename' => 'modEvent/74f869894643e75e600ed7e3612620d0.vehicle',
      'namespace' => 'cybershop',
    ),
    36 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a08c7ab53bb38ac5445a2388273f119c',
      'native_key' => 'csOnBeforeAddToOrder',
      'filename' => 'modEvent/6725783475b196ec0a499fefd63694a2.vehicle',
      'namespace' => 'cybershop',
    ),
    37 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '75933a5f049d7aaaa9f9ffa3dbd3d8c4',
      'native_key' => 'csOnAddToOrder',
      'filename' => 'modEvent/2588a4f96f33bed5370790997bca6d29.vehicle',
      'namespace' => 'cybershop',
    ),
    38 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1e9bf1f3a10a17d75f6c52eb61099796',
      'native_key' => 'csOnBeforeRemoveFromOrder',
      'filename' => 'modEvent/91d63aac2640bfe9e9549ccca6c1fe7b.vehicle',
      'namespace' => 'cybershop',
    ),
    39 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '30168a4b69e983c4191054525b56295a',
      'native_key' => 'csOnRemoveFromOrder',
      'filename' => 'modEvent/a20b3e4fa53ad392e187cd9908a2e2d0.vehicle',
      'namespace' => 'cybershop',
    ),
    40 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '84061656f37465556b8e9f47ec096eb0',
      'native_key' => 'csOnBeforeEmptyOrder',
      'filename' => 'modEvent/7a39731f8ff3a75264923cda6d16e19c.vehicle',
      'namespace' => 'cybershop',
    ),
    41 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bc6fc0b522b26bec290d0ed5f3646f48',
      'native_key' => 'csOnEmptyOrder',
      'filename' => 'modEvent/6bc0fdaa6cf051a8ffc965dd417ab734.vehicle',
      'namespace' => 'cybershop',
    ),
    42 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3d6401ced3f265d224097c2275cdd747',
      'native_key' => 'csOnBeforeChangeOrderStatus',
      'filename' => 'modEvent/835f0902e20c2675d1d993d455492932.vehicle',
      'namespace' => 'cybershop',
    ),
    43 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '60412952ebe8d41a459d26cc37738789',
      'native_key' => 'csOnChangeOrderStatus',
      'filename' => 'modEvent/b2f5f643568a909c56ce0d2691375caa.vehicle',
      'namespace' => 'cybershop',
    ),
    44 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'da5d2a89a3d9bda53662fcbd038edec6',
      'native_key' => 'csOnBeforeUpdateOrder',
      'filename' => 'modEvent/55ed1a6f14f63268b31c420c3faefabb.vehicle',
      'namespace' => 'cybershop',
    ),
    45 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b89c2e418cb9bdaf55bbbfbada921fbc',
      'native_key' => 'csOnUpdateOrder',
      'filename' => 'modEvent/39d4e2424e13a1fb393f285728461875.vehicle',
      'namespace' => 'cybershop',
    ),
    46 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd0cf02a2f628fd9b1f1e936ab049910e',
      'native_key' => 'csOnBeforeCreateOrder',
      'filename' => 'modEvent/5fac7aaea9d0b6e4f05a008dad018d5f.vehicle',
      'namespace' => 'cybershop',
    ),
    47 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9ed0b6fef7414a84ff8cefb0aa254e2d',
      'native_key' => 'csOnCreateOrder',
      'filename' => 'modEvent/c9917b039bbd6bb70dd4155fca481c57.vehicle',
      'namespace' => 'cybershop',
    ),
    48 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '940279a7fd5711b798256f4663a58196',
      'native_key' => 'csOnSubmitOrder',
      'filename' => 'modEvent/8f3d8326085c88b591c4d32b64f0d775.vehicle',
      'namespace' => 'cybershop',
    ),
    49 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6d50a4cabc868d6b6b73d1b2d6117f4c',
      'native_key' => 'csOnManagerCustomCssJs',
      'filename' => 'modEvent/4c68a8e6d5c813f861b2a8f619043135.vehicle',
      'namespace' => 'cybershop',
    ),
    50 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'b460480568cf10ca3863f0c8f99d5cbb',
      'native_key' => 0,
      'filename' => 'modAccessPolicy/67cff5a00ecb97137e61311cee8b3b1d.vehicle',
      'namespace' => 'cybershop',
    ),
    51 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => 'b3593065a7a054fb64c11f2d878b6b23',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/875712f941078c61fc2925f79d7b5ff3.vehicle',
      'namespace' => 'cybershop',
    ),
    52 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroup',
      'guid' => '39db1bf144b431404b4175ed08423b0e',
      'native_key' => 0,
      'filename' => 'modUserGroup/ce9ccaa7d5b9999305ed4c7ecddab8c2.vehicle',
      'namespace' => 'cybershop',
    ),
    53 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '4bc46281a341c45afbd889471a118ba3',
      'native_key' => 'cybershop',
      'filename' => 'modMenu/6f4e1b869e304bccca85097b5017555d.vehicle',
      'namespace' => 'cybershop',
    ),
    54 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'acee6a5e8d54d4fed08665f5bccf8c33',
      'native_key' => 'cs_orders',
      'filename' => 'modMenu/ce7cea52d85807e40af59d42382f96da.vehicle',
      'namespace' => 'cybershop',
    ),
    55 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '067b0ef8bab88a32d49a7083fc906476',
      'native_key' => 'cs_catalog',
      'filename' => 'modMenu/f1bdfb6439ca5eb4e554793a183c394b.vehicle',
      'namespace' => 'cybershop',
    ),
    56 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '1c565628a5207e63da882a64b7360779',
      'native_key' => 'cs_settings',
      'filename' => 'modMenu/ed5b1df0118520846f429ab588e92731.vehicle',
      'namespace' => 'cybershop',
    ),
    57 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'e3e06c92163f0f547022b5db82b12615',
      'native_key' => 'cs_categorys',
      'filename' => 'modMenu/440e76c83ba8bd26c602ef6f14c62eb1.vehicle',
      'namespace' => 'cybershop',
    ),
    58 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '273baa17be00c34283d81e87366e34bd',
      'native_key' => 'cs_brands',
      'filename' => 'modMenu/8e2a03c12beeb81aeb747b5d45a75907.vehicle',
      'namespace' => 'cybershop',
    ),
    59 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '46732b3a2038230cb0b06e96aafe4ac2',
      'native_key' => 'cs_filters',
      'filename' => 'modMenu/04b7ebfe36a480fe54551aa89fac4fc9.vehicle',
      'namespace' => 'cybershop',
    ),
    60 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '5efdc9542bc43a67d6ead0ebb9322967',
      'native_key' => 'cs_properties',
      'filename' => 'modMenu/a247ffc52f525c967c4489c665c0fc62.vehicle',
      'namespace' => 'cybershop',
    ),
    61 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '8785c50cc17625163950030fcbfb7a94',
      'native_key' => 'cs_payment',
      'filename' => 'modMenu/98f5b2fbc50a75fba27fabb991c4a22b.vehicle',
      'namespace' => 'cybershop',
    ),
    62 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'f38e499089236c8508bc41e3d5b413d4',
      'native_key' => 'cs_status',
      'filename' => 'modMenu/9b8fa96c459c69a1b2238a715a45348d.vehicle',
      'namespace' => 'cybershop',
    ),
    63 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '1191d5b2c4686e9fb7639d92183de7e6',
      'native_key' => 'cs_delivery',
      'filename' => 'modMenu/aa42c6c951c65e6cbcc0dd09283a01f1.vehicle',
      'namespace' => 'cybershop',
    ),
    64 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '144522729aa18d7057f86264864a4ee9',
      'native_key' => 'cs_currency',
      'filename' => 'modMenu/ab8f91af66640e0a92d116e6d397acf4.vehicle',
      'namespace' => 'cybershop',
    ),
    65 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'b03b920933d416e3bc7dadc89efc5732',
      'native_key' => 1,
      'filename' => 'modCategory/5b341bc589ed253abdec070fb1347797.vehicle',
      'namespace' => 'cybershop',
    ),
  ),
);
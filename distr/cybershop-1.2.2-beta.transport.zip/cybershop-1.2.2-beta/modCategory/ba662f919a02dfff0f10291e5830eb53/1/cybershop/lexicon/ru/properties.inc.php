<?php
/**
 * @package doodles
 * @subpackage lexicon
 */

$_lang = array();

$_lang['prop_cs.lang'] = 'Язык';

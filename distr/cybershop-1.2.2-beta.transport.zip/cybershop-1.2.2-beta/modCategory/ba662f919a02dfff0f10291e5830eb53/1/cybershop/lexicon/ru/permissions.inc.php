<?php
/**
 * Permissions Russian Lexicon Entries for cybershop
 *
 * @package cybershop
 * @subpackage lexicon
 */
$_lang['csorder_view'] = 'Разрешает просмотр заказа';
$_lang['csorder_save'] = 'Разрешает изменение заказа';
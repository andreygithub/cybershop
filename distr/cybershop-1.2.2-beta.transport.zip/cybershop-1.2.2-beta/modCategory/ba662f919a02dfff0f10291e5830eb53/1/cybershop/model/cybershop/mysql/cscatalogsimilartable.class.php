<?php
require_once (dirname(dirname(__FILE__)) . '/cscatalogsimilartable.class.php');
class csCatalogSimilarTable_mysql extends csCatalogSimilarTable {}
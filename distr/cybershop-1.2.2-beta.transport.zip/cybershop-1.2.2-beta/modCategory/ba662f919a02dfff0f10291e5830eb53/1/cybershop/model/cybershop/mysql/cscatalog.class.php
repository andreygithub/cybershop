<?php
require_once (dirname(dirname(__FILE__)) . '/cscatalog.class.php');
class csCatalog_mysql extends csCatalog {}
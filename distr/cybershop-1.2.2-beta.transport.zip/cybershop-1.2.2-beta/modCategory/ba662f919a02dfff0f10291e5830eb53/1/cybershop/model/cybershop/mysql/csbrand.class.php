<?php
require_once (dirname(dirname(__FILE__)) . '/csbrand.class.php');
class csBrand_mysql extends csBrand {}
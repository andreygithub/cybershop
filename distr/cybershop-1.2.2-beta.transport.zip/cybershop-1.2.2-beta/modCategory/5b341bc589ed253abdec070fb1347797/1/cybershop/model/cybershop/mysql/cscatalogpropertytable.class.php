<?php
require_once (dirname(dirname(__FILE__)) . '/cscatalogpropertytable.class.php');
class csCatalogPropertyTable_mysql extends csCatalogPropertyTable {}
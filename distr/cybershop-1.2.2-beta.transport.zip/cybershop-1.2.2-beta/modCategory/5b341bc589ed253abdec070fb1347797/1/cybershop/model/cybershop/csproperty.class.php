<?php
class csProperty extends xPDOSimpleObject {}
<?php
class csCatalogImageTable extends xPDOSimpleObject {}
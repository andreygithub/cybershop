<?php
require_once (dirname(dirname(__FILE__)) . '/cscatalogcomplecttable.class.php');
class csCatalogComplectTable_mysql extends csCatalogComplectTable {}
<?php
require_once (dirname(dirname(__FILE__)) . '/csproperty.class.php');
class csProperty_mysql extends csProperty {}
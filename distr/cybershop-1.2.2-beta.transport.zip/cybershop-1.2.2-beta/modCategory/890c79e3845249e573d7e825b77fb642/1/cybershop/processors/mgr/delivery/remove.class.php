<?php

class csDeliveryRemoveProcessor extends modObjectRemoveProcessor  {
	public $checkRemovePermission = true;
	public $classKey = 'csDelivery';
	public $languageTopics = array('cybershop');

}
return 'csDeliveryRemoveProcessor';
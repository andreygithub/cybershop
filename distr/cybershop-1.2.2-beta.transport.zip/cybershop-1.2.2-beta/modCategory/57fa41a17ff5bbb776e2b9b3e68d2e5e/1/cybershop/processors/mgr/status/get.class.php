<?php

class csOrderStatusGetProcessor extends modObjectGetProcessor {
	public $classKey = 'csOrderStatus';
	public $languageTopics = array('cybershop');
	public $objectType = 'cs_order_status';
}

return 'csOrderStatusGetProcessor';
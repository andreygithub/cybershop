<?php
require_once (dirname(dirname(__FILE__)) . '/csdelivery.class.php');
class csDelivery_mysql extends csDelivery {}
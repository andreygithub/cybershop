<?php
class csCategoryPropertyTable extends xPDOSimpleObject {}
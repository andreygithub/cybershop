<?php
class csOrder extends xPDOSimpleObject {}
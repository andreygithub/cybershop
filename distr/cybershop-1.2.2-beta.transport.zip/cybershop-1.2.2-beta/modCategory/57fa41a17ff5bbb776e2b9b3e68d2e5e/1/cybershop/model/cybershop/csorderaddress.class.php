<?php
class csOrderAddress extends xPDOSimpleObject {}
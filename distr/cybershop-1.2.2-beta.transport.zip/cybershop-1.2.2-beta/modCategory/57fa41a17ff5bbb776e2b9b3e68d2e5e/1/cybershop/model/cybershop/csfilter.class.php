<?php
class csFilter extends xPDOSimpleObject {}